# Assignment 2

You can run the application using the built-in PHP web server:

```
php -S localhost:7777 src/
```
