<?php
// Destroy the session to log out the user