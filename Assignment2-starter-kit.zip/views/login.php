<?php

require_once '../src/Repositories/UserRepository.php';

use src\Repositories\UserRepository;

// Display a login form and handle login attempts
