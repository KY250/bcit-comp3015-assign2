<?php

require_once '../src/Repositories/ArticleRepository.php';

use src\Repositories\ArticleRepository;

// Handle creating a new article here.
