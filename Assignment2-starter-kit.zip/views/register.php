<?php

// display a registration form and create new accounts here, with the help of the UserRepository class
