<?php

require_once '../src/Repositories/UserRepository.php';
require_once '../src/Models/User.php';

// Reusable navigation bar. You will need to use the UserRepository to show the name
// and start a session in order to determine the user authentication status e.g. checking $_SESSION['user_id']

