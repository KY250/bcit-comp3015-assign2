<?php
require_once '../src/Repositories/ArticleRepository.php';
require_once '../src/Repositories/UserRepository.php';

use src\Repositories\ArticleRepository;
use src\Repositories\UserRepository;
