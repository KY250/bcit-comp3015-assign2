<?php

// An update article form should be shown here, similar to the lab.
