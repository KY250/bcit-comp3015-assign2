<?php
// Handle the user changing their username and profile picture uploads here
