<?php
require_once '../src/Repositories/ArticleRepository.php';

use src\Repositories\ArticleRepository;

$articleRepository = new ArticleRepository();
$articles = $articleRepository->getAllArticles();
?>

<?php require_once 'header.php'; ?>

<body>

<?php require_once 'nav.php' ?>

<div>

    <h1>Articles</h1>

	<?= count($articles) === 0 ? "No articles yet :(" : ""; ?>

    <div>
        <ul>

			<?php foreach ($articles as $article): ?>
                <!--        Display all the articles        -->
			<?php endforeach; ?>

        </ul>
    </div>

</div>

</body>
