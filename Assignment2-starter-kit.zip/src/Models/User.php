<?php

namespace src\Models;

require_once 'Model.php';

class User extends Model {

}
