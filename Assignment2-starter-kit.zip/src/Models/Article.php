<?php

namespace src\Models;

require_once 'Model.php';

class Article extends Model {

}
